<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_d5b17cba9f0bd9ae9bf7b8618c290b049c365eece78811cd2687152c11455116 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ddb789d37287ffe2ecf3a1e2fb6554189b276259b27cfc63c5a85c6f90b02de7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ddb789d37287ffe2ecf3a1e2fb6554189b276259b27cfc63c5a85c6f90b02de7->enter($__internal_ddb789d37287ffe2ecf3a1e2fb6554189b276259b27cfc63c5a85c6f90b02de7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ddb789d37287ffe2ecf3a1e2fb6554189b276259b27cfc63c5a85c6f90b02de7->leave($__internal_ddb789d37287ffe2ecf3a1e2fb6554189b276259b27cfc63c5a85c6f90b02de7_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7deec05f0171ccd091686db8e01bcb7a5ea7d322990b341fa1b2c93071a36cee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7deec05f0171ccd091686db8e01bcb7a5ea7d322990b341fa1b2c93071a36cee->enter($__internal_7deec05f0171ccd091686db8e01bcb7a5ea7d322990b341fa1b2c93071a36cee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_7deec05f0171ccd091686db8e01bcb7a5ea7d322990b341fa1b2c93071a36cee->leave($__internal_7deec05f0171ccd091686db8e01bcb7a5ea7d322990b341fa1b2c93071a36cee_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_7964c915e0892f3781a53e9bdd82e37262897fe2c88b05e9c96daded49ad5a33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7964c915e0892f3781a53e9bdd82e37262897fe2c88b05e9c96daded49ad5a33->enter($__internal_7964c915e0892f3781a53e9bdd82e37262897fe2c88b05e9c96daded49ad5a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_7964c915e0892f3781a53e9bdd82e37262897fe2c88b05e9c96daded49ad5a33->leave($__internal_7964c915e0892f3781a53e9bdd82e37262897fe2c88b05e9c96daded49ad5a33_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
