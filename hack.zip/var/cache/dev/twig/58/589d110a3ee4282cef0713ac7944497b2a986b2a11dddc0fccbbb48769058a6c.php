<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_061f1d76a5e686cd7809995cd4d3fc1f4c1294393e57d9d5a707b9026d69b108 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_496663adfc435bb7ebb104027ae03ee89c243c105720f4dd7a3b8fd9f071a920 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_496663adfc435bb7ebb104027ae03ee89c243c105720f4dd7a3b8fd9f071a920->enter($__internal_496663adfc435bb7ebb104027ae03ee89c243c105720f4dd7a3b8fd9f071a920_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_496663adfc435bb7ebb104027ae03ee89c243c105720f4dd7a3b8fd9f071a920->leave($__internal_496663adfc435bb7ebb104027ae03ee89c243c105720f4dd7a3b8fd9f071a920_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
