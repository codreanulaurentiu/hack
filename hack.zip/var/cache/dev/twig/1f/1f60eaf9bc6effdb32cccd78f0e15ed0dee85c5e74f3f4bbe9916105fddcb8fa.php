<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_3999756dc4699195269423c486fe4765502dc263856eeb87d63ceb8c6ba26e46 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd24d78df6d72adfce4645d887f842f14e9791ed409425badfbf74b51d81fe2d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd24d78df6d72adfce4645d887f842f14e9791ed409425badfbf74b51d81fe2d->enter($__internal_dd24d78df6d72adfce4645d887f842f14e9791ed409425badfbf74b51d81fe2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd24d78df6d72adfce4645d887f842f14e9791ed409425badfbf74b51d81fe2d->leave($__internal_dd24d78df6d72adfce4645d887f842f14e9791ed409425badfbf74b51d81fe2d_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_071b757ac06e9a472ccb3a1b4e12ee0195598136e366b55f9cd3409ddda4f78f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_071b757ac06e9a472ccb3a1b4e12ee0195598136e366b55f9cd3409ddda4f78f->enter($__internal_071b757ac06e9a472ccb3a1b4e12ee0195598136e366b55f9cd3409ddda4f78f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_071b757ac06e9a472ccb3a1b4e12ee0195598136e366b55f9cd3409ddda4f78f->leave($__internal_071b757ac06e9a472ccb3a1b4e12ee0195598136e366b55f9cd3409ddda4f78f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_4c655c5dbcdfcb04b4dfadac0db27d760edab93cf3f1684b41de33739525cfc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c655c5dbcdfcb04b4dfadac0db27d760edab93cf3f1684b41de33739525cfc2->enter($__internal_4c655c5dbcdfcb04b4dfadac0db27d760edab93cf3f1684b41de33739525cfc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_4c655c5dbcdfcb04b4dfadac0db27d760edab93cf3f1684b41de33739525cfc2->leave($__internal_4c655c5dbcdfcb04b4dfadac0db27d760edab93cf3f1684b41de33739525cfc2_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_36deff27287cb86a662b3a19dcfc6b8b72643e2d7968597b091ea491d5a3a28c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36deff27287cb86a662b3a19dcfc6b8b72643e2d7968597b091ea491d5a3a28c->enter($__internal_36deff27287cb86a662b3a19dcfc6b8b72643e2d7968597b091ea491d5a3a28c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_36deff27287cb86a662b3a19dcfc6b8b72643e2d7968597b091ea491d5a3a28c->leave($__internal_36deff27287cb86a662b3a19dcfc6b8b72643e2d7968597b091ea491d5a3a28c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
