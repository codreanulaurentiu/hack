<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_afaec2b3e8f370cb3a28a0f82f5edfeed3b8130b8f66a84c463ece3293611df4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53e2b2280a061d3e67e67ac8542c3d806b70758833b0f75146daf4da08ec116c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53e2b2280a061d3e67e67ac8542c3d806b70758833b0f75146daf4da08ec116c->enter($__internal_53e2b2280a061d3e67e67ac8542c3d806b70758833b0f75146daf4da08ec116c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_53e2b2280a061d3e67e67ac8542c3d806b70758833b0f75146daf4da08ec116c->leave($__internal_53e2b2280a061d3e67e67ac8542c3d806b70758833b0f75146daf4da08ec116c_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_1f8e5930261367dc1aa60d9701734f4a7d3b86657c24c26b5cd54a6c3481b232 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f8e5930261367dc1aa60d9701734f4a7d3b86657c24c26b5cd54a6c3481b232->enter($__internal_1f8e5930261367dc1aa60d9701734f4a7d3b86657c24c26b5cd54a6c3481b232_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_1f8e5930261367dc1aa60d9701734f4a7d3b86657c24c26b5cd54a6c3481b232->leave($__internal_1f8e5930261367dc1aa60d9701734f4a7d3b86657c24c26b5cd54a6c3481b232_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_c69a9f51ef2e656f5068dff725bfeedef24091f0418d590c0c7b9a490852fade = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c69a9f51ef2e656f5068dff725bfeedef24091f0418d590c0c7b9a490852fade->enter($__internal_c69a9f51ef2e656f5068dff725bfeedef24091f0418d590c0c7b9a490852fade_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_c69a9f51ef2e656f5068dff725bfeedef24091f0418d590c0c7b9a490852fade->leave($__internal_c69a9f51ef2e656f5068dff725bfeedef24091f0418d590c0c7b9a490852fade_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_a8789389869921726a1595e5e2650e8448986c97d9c3dc84d86e5f32927bc684 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8789389869921726a1595e5e2650e8448986c97d9c3dc84d86e5f32927bc684->enter($__internal_a8789389869921726a1595e5e2650e8448986c97d9c3dc84d86e5f32927bc684_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_a8789389869921726a1595e5e2650e8448986c97d9c3dc84d86e5f32927bc684->leave($__internal_a8789389869921726a1595e5e2650e8448986c97d9c3dc84d86e5f32927bc684_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "TwigBundle:Exception:exception_full.html.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
