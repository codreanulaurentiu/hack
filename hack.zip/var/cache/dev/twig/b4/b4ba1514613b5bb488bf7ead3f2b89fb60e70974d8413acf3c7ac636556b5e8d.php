<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_23ab80107be34aece83ce0589697c5e2457eeb8964d433715abae8893ea5c21f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_efd43d54dd76d6e71e4a6f005ee315c3ac27008484288d282e47a48932830b1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efd43d54dd76d6e71e4a6f005ee315c3ac27008484288d282e47a48932830b1f->enter($__internal_efd43d54dd76d6e71e4a6f005ee315c3ac27008484288d282e47a48932830b1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_efd43d54dd76d6e71e4a6f005ee315c3ac27008484288d282e47a48932830b1f->leave($__internal_efd43d54dd76d6e71e4a6f005ee315c3ac27008484288d282e47a48932830b1f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/button_label.html.php");
    }
}
