<?php

/* user/login.html.twig */
class __TwigTemplate_cc1f59f98e0dc840c11950401b256a1a7aa785b427154e866ecd73eeb84321f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b5b5c9043e80ec15526b469e8ed8fe8077afc4d0799ac97528430ab92e54f82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b5b5c9043e80ec15526b469e8ed8fe8077afc4d0799ac97528430ab92e54f82->enter($__internal_1b5b5c9043e80ec15526b469e8ed8fe8077afc4d0799ac97528430ab92e54f82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/login.html.twig"));

        // line 1
        echo "<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<link rel=\"stylesheet\" href=\"bundles/app/css/normalize.css\">
<link rel=\"stylesheet\" href=\"bundles/app/css/login.css\">
<script type=\"text/javascript\" src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/jquery-3.1.1.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/loginChecker.js"), "html", null, true);
        echo "\"></script>
<script src=\"bundles/app/js/index.js\"></script>

<div class=\"form\">

    <ul class=\"tab-group\">
        <li class=\"tab \"><a href=";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_registration");
        echo ">Sign Up</a></li>
        <li class=\"tab active\"><a href=";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_login");
        echo ">Log In</a></li>
    </ul>

    <div class=\"tab-content\">
        <div id=\"signup\">
            <h1>Login</h1>
            ";
        // line 18
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "

            <div class=\"field-wrap max \">
                ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "Username", array()), 'row');
        echo "
                <span class=\"req\">*</span>
            </div>

            <div class=\"field-wrap max\">
                ";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "Password", array()), 'row');
        echo "
            </div>

            <button type=\"submit\" class=\"button button-block\">Login!</button>
            ";
        // line 30
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
        <div id=\"login\">
            <h1>Welcome Back!</h1>

            <form action=\"/\" method=\"post\">

                <div class=\"field-wrap\">
                    <label>
                        Email Address<span class=\"req\">*</span>
                    </label>
                    <input type=\"email\"required autocomplete=\"off\"/>
                </div>

                <div class=\"field-wrap\">
                    <label>
                        Password<span class=\"req\">*</span>
                    </label>
                    <input type=\"password\"required autocomplete=\"off\"/>
                </div>

                <p class=\"forgot\"><a href=\"#\">Forgot Password?</a></p>

                <button class=\"button button-block\"/>Log In</button>

            </form>

        </div>

    </div><!-- tab-content -->

</div> <!-- /form -->



















";
        
        $__internal_1b5b5c9043e80ec15526b469e8ed8fe8077afc4d0799ac97528430ab92e54f82->leave($__internal_1b5b5c9043e80ec15526b469e8ed8fe8077afc4d0799ac97528430ab92e54f82_prof);

    }

    public function getTemplateName()
    {
        return "user/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 30,  67 => 26,  59 => 21,  53 => 18,  44 => 12,  40 => 11,  31 => 5,  27 => 4,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<link rel=\"stylesheet\" href=\"bundles/app/css/normalize.css\">
<link rel=\"stylesheet\" href=\"bundles/app/css/login.css\">
<script type=\"text/javascript\" src=\"{{ asset('bundles/app/js/jquery-3.1.1.min.js') }}\"></script>
<script type=\"text/javascript\" src=\"{{ asset('bundles/app/js/loginChecker.js') }}\"></script>
<script src=\"bundles/app/js/index.js\"></script>

<div class=\"form\">

    <ul class=\"tab-group\">
        <li class=\"tab \"><a href={{ path('user_registration') }}>Sign Up</a></li>
        <li class=\"tab active\"><a href={{ path('user_login') }}>Log In</a></li>
    </ul>

    <div class=\"tab-content\">
        <div id=\"signup\">
            <h1>Login</h1>
            {{ form_start(form) }}

            <div class=\"field-wrap max \">
                {{ form_row(form.Username) }}
                <span class=\"req\">*</span>
            </div>

            <div class=\"field-wrap max\">
                {{ form_row(form.Password) }}
            </div>

            <button type=\"submit\" class=\"button button-block\">Login!</button>
            {{ form_end(form) }}
        </div>
        <div id=\"login\">
            <h1>Welcome Back!</h1>

            <form action=\"/\" method=\"post\">

                <div class=\"field-wrap\">
                    <label>
                        Email Address<span class=\"req\">*</span>
                    </label>
                    <input type=\"email\"required autocomplete=\"off\"/>
                </div>

                <div class=\"field-wrap\">
                    <label>
                        Password<span class=\"req\">*</span>
                    </label>
                    <input type=\"password\"required autocomplete=\"off\"/>
                </div>

                <p class=\"forgot\"><a href=\"#\">Forgot Password?</a></p>

                <button class=\"button button-block\"/>Log In</button>

            </form>

        </div>

    </div><!-- tab-content -->

</div> <!-- /form -->



















", "user/login.html.twig", "/home/laurentiu/Desktop/hack/app/Resources/views/user/login.html.twig");
    }
}
