<?php

/* ::base.html.twig */
class __TwigTemplate_e4bdd2a03091d83677a435a6b5b9ddb5e191ec81c5a92a71704ddfd86369102c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e714bdabc11f6c4a607490d5e21fbb2c667bb8b8492eeaa6b33f493d7cbefe0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e714bdabc11f6c4a607490d5e21fbb2c667bb8b8492eeaa6b33f493d7cbefe0e->enter($__internal_e714bdabc11f6c4a607490d5e21fbb2c667bb8b8492eeaa6b33f493d7cbefe0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_e714bdabc11f6c4a607490d5e21fbb2c667bb8b8492eeaa6b33f493d7cbefe0e->leave($__internal_e714bdabc11f6c4a607490d5e21fbb2c667bb8b8492eeaa6b33f493d7cbefe0e_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f9242e93e6634e9b115d84b96e5e0cedb2560404a07ea84d2acd65be71c94062 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9242e93e6634e9b115d84b96e5e0cedb2560404a07ea84d2acd65be71c94062->enter($__internal_f9242e93e6634e9b115d84b96e5e0cedb2560404a07ea84d2acd65be71c94062_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_f9242e93e6634e9b115d84b96e5e0cedb2560404a07ea84d2acd65be71c94062->leave($__internal_f9242e93e6634e9b115d84b96e5e0cedb2560404a07ea84d2acd65be71c94062_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0a4efa4f0610f8382ff6db09907f363c18e6c8dc0ca534475b7d912e96ac2c62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a4efa4f0610f8382ff6db09907f363c18e6c8dc0ca534475b7d912e96ac2c62->enter($__internal_0a4efa4f0610f8382ff6db09907f363c18e6c8dc0ca534475b7d912e96ac2c62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0a4efa4f0610f8382ff6db09907f363c18e6c8dc0ca534475b7d912e96ac2c62->leave($__internal_0a4efa4f0610f8382ff6db09907f363c18e6c8dc0ca534475b7d912e96ac2c62_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_ac7e8edfd1eb5689e8ade73a0a1e1a8c8b66fdd8f4f2884eedf35ea29d026d14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac7e8edfd1eb5689e8ade73a0a1e1a8c8b66fdd8f4f2884eedf35ea29d026d14->enter($__internal_ac7e8edfd1eb5689e8ade73a0a1e1a8c8b66fdd8f4f2884eedf35ea29d026d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_ac7e8edfd1eb5689e8ade73a0a1e1a8c8b66fdd8f4f2884eedf35ea29d026d14->leave($__internal_ac7e8edfd1eb5689e8ade73a0a1e1a8c8b66fdd8f4f2884eedf35ea29d026d14_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4fcedc5e2d2aca7feb6c2d8e356b147ec62b9481e918cd24e5840dac6201111f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4fcedc5e2d2aca7feb6c2d8e356b147ec62b9481e918cd24e5840dac6201111f->enter($__internal_4fcedc5e2d2aca7feb6c2d8e356b147ec62b9481e918cd24e5840dac6201111f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4fcedc5e2d2aca7feb6c2d8e356b147ec62b9481e918cd24e5840dac6201111f->leave($__internal_4fcedc5e2d2aca7feb6c2d8e356b147ec62b9481e918cd24e5840dac6201111f_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/home/laurentiu/Desktop/hack/app/Resources/views/base.html.twig");
    }
}
