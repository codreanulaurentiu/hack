<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_f3a6e4cdd9ec39298958f729f769fda5bd475bbeef365c4cc1c26758040bace5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e46a73f0ea239e18f8ac42f0e9f1f7d35c1ffd95d76d70c1e5c9fd002481d255 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e46a73f0ea239e18f8ac42f0e9f1f7d35c1ffd95d76d70c1e5c9fd002481d255->enter($__internal_e46a73f0ea239e18f8ac42f0e9f1f7d35c1ffd95d76d70c1e5c9fd002481d255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_e46a73f0ea239e18f8ac42f0e9f1f7d35c1ffd95d76d70c1e5c9fd002481d255->leave($__internal_e46a73f0ea239e18f8ac42f0e9f1f7d35c1ffd95d76d70c1e5c9fd002481d255_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
