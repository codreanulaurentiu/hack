<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_6005975f0680e4033b2f4ed3e1cf8e7a3ba4a0a5662b1124d0ff0ba152eb9394 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c516699d4c2a554c818f04cd62982f7ae412609564e5ec84f54177c952d9f00b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c516699d4c2a554c818f04cd62982f7ae412609564e5ec84f54177c952d9f00b->enter($__internal_c516699d4c2a554c818f04cd62982f7ae412609564e5ec84f54177c952d9f00b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_c516699d4c2a554c818f04cd62982f7ae412609564e5ec84f54177c952d9f00b->leave($__internal_c516699d4c2a554c818f04cd62982f7ae412609564e5ec84f54177c952d9f00b_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_279f348c22d334238ea3bd0df572b1f03a469f85104eccea4aab01137e12bece = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_279f348c22d334238ea3bd0df572b1f03a469f85104eccea4aab01137e12bece->enter($__internal_279f348c22d334238ea3bd0df572b1f03a469f85104eccea4aab01137e12bece_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_279f348c22d334238ea3bd0df572b1f03a469f85104eccea4aab01137e12bece->leave($__internal_279f348c22d334238ea3bd0df572b1f03a469f85104eccea4aab01137e12bece_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
