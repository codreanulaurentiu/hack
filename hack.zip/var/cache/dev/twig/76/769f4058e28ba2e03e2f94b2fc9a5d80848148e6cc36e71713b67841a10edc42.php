<?php

/* :user:register.html.twig */
class __TwigTemplate_8fcf65d9f02ccc24f0b610d105d04e37f8941e6ef9a4edb6ba5079fea4a88fb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57cf29041045c2c1d00c311f484fa115ac287a973715629586b6da4cc85f0085 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57cf29041045c2c1d00c311f484fa115ac287a973715629586b6da4cc85f0085->enter($__internal_57cf29041045c2c1d00c311f484fa115ac287a973715629586b6da4cc85f0085_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user:register.html.twig"));

        // line 1
        echo "<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<link rel=\"stylesheet\" href=\"bundles/app/css/normalize.css\">
<link rel=\"stylesheet\" href=\"bundles/app/css/login.css\">
<script type=\"text/javascript\" src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/jquery-3.1.1.min.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\" src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/app/js/registerChecker.js"), "html", null, true);
        echo "\"></script>
<script src=\"bundles/app/js/index.js\"></script>

<div class=\"form\">

    <ul class=\"tab-group\">
        <li class=\"tab active\"><a href=\"/register\">Sign Up</a></li>
        <li class=\"tab\"><a href=\"/login\">Log In</a></li>
    </ul>

    <div class=\"tab-content\">
        <div id=\"signup\">
            <h1>Sign Up for Free</h1>

            ";
        // line 19
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "

                <div class=\"top-row\">
                    <div class=\"field-wrap max\">
                        ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "username", array()), 'row');
        echo "
                        <span class=\"req\">*</span>
                    </div>

                    <div class=\"field-wrap max\">
                        ";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "email", array()), 'row');
        echo "
                        <span class=\"req\">*</span>
                    </div>
                </div>

                <div class=\"field-wrap max \">
                    ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "firstName", array()), 'row');
        echo "
                    <span class=\"req\">*</span>
                </div>

                <div class=\"field-wrap max \">
                    ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "lastName", array()), 'row');
        echo "
                    <span class=\"req\">*</span>
                </div>


            <div class=\"field-wrap max\">
                    ";
        // line 45
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "first", array()), 'row');
        echo "
                </div>
                <div class=\"field-wrap max\">
                    ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "plainPassword", array()), "second", array()), 'row');
        echo "
                </div>
                <button type=\"submit\" class=\"button button-block\">Register!</button>
            ";
        // line 51
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
        <div id=\"login\">
            <h1>Welcome Back!</h1>

            <form action=\"/\" method=\"post\">

                <div class=\"field-wrap\">
                    <label>
                        Email Address<span class=\"req\">*</span>
                    </label>
                    <input type=\"email\"required autocomplete=\"off\"/>
                </div>

                <div class=\"field-wrap\">
                    <label>
                        Password<span class=\"req\">*</span>
                    </label>
                    <input type=\"password\"required autocomplete=\"off\"/>
                </div>

                <p class=\"forgot\"><a href=\"#\">Forgot Password?</a></p>

                <button class=\"button button-block\"/>Log In</button>

            </form>

        </div>

    </div><!-- tab-content -->

</div> <!-- /form -->









";
        
        $__internal_57cf29041045c2c1d00c311f484fa115ac287a973715629586b6da4cc85f0085->leave($__internal_57cf29041045c2c1d00c311f484fa115ac287a973715629586b6da4cc85f0085_prof);

    }

    public function getTemplateName()
    {
        return ":user:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 51,  95 => 48,  89 => 45,  80 => 39,  72 => 34,  63 => 28,  55 => 23,  48 => 19,  31 => 5,  27 => 4,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
<link rel=\"stylesheet\" href=\"bundles/app/css/normalize.css\">
<link rel=\"stylesheet\" href=\"bundles/app/css/login.css\">
<script type=\"text/javascript\" src=\"{{ asset('bundles/app/js/jquery-3.1.1.min.js') }}\"></script>
<script type=\"text/javascript\" src=\"{{ asset('bundles/app/js/registerChecker.js') }}\"></script>
<script src=\"bundles/app/js/index.js\"></script>

<div class=\"form\">

    <ul class=\"tab-group\">
        <li class=\"tab active\"><a href=\"/register\">Sign Up</a></li>
        <li class=\"tab\"><a href=\"/login\">Log In</a></li>
    </ul>

    <div class=\"tab-content\">
        <div id=\"signup\">
            <h1>Sign Up for Free</h1>

            {{ form_start(form) }}

                <div class=\"top-row\">
                    <div class=\"field-wrap max\">
                        {{ form_row(form.username) }}
                        <span class=\"req\">*</span>
                    </div>

                    <div class=\"field-wrap max\">
                        {{ form_row(form.email) }}
                        <span class=\"req\">*</span>
                    </div>
                </div>

                <div class=\"field-wrap max \">
                    {{ form_row(form.firstName) }}
                    <span class=\"req\">*</span>
                </div>

                <div class=\"field-wrap max \">
                    {{ form_row(form.lastName) }}
                    <span class=\"req\">*</span>
                </div>


            <div class=\"field-wrap max\">
                    {{ form_row(form.plainPassword.first) }}
                </div>
                <div class=\"field-wrap max\">
                    {{ form_row(form.plainPassword.second) }}
                </div>
                <button type=\"submit\" class=\"button button-block\">Register!</button>
            {{ form_end(form) }}
        </div>
        <div id=\"login\">
            <h1>Welcome Back!</h1>

            <form action=\"/\" method=\"post\">

                <div class=\"field-wrap\">
                    <label>
                        Email Address<span class=\"req\">*</span>
                    </label>
                    <input type=\"email\"required autocomplete=\"off\"/>
                </div>

                <div class=\"field-wrap\">
                    <label>
                        Password<span class=\"req\">*</span>
                    </label>
                    <input type=\"password\"required autocomplete=\"off\"/>
                </div>

                <p class=\"forgot\"><a href=\"#\">Forgot Password?</a></p>

                <button class=\"button button-block\"/>Log In</button>

            </form>

        </div>

    </div><!-- tab-content -->

</div> <!-- /form -->









", ":user:register.html.twig", "/home/laurentiu/Desktop/hack/app/Resources/views/user/register.html.twig");
    }
}
