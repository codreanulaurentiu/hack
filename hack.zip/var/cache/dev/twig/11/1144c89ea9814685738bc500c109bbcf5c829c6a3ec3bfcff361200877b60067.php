<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_5edfc48af0178c76bb9e052b683a67b6644c961fc05075533df842051f9731db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5627c08c2cefe72c15fc2b59f298e1c8503e65079317192224a0267b42b8f5d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5627c08c2cefe72c15fc2b59f298e1c8503e65079317192224a0267b42b8f5d9->enter($__internal_5627c08c2cefe72c15fc2b59f298e1c8503e65079317192224a0267b42b8f5d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_5627c08c2cefe72c15fc2b59f298e1c8503e65079317192224a0267b42b8f5d9->leave($__internal_5627c08c2cefe72c15fc2b59f298e1c8503e65079317192224a0267b42b8f5d9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views/Form/container_attributes.html.php");
    }
}
