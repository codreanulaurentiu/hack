<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_85769d9d2d4b04ecade15de84f747ab9b8aba2abf67fd91fc36d9561070f4d15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef8a151052897db336f7740f8a7650f3bdba3ec7baa2dc01f9e5cfa4d6fee515 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef8a151052897db336f7740f8a7650f3bdba3ec7baa2dc01f9e5cfa4d6fee515->enter($__internal_ef8a151052897db336f7740f8a7650f3bdba3ec7baa2dc01f9e5cfa4d6fee515_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        
        $__internal_ef8a151052897db336f7740f8a7650f3bdba3ec7baa2dc01f9e5cfa4d6fee515->leave($__internal_ef8a151052897db336f7740f8a7650f3bdba3ec7baa2dc01f9e5cfa4d6fee515_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "/home/laurentiu/Desktop/hack/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
