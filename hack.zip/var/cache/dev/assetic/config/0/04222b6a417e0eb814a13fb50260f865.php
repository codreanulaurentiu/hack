<?php

// WebProfilerBundle:Profiler:layout.html.twig
return array (
);
