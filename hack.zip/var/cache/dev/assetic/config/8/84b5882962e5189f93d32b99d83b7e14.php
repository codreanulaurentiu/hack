<?php

// TwigBundle:Exception:exception.json.twig
return array (
);
