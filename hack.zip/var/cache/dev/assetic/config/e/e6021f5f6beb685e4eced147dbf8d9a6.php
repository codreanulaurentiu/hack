<?php

// WebProfilerBundle:Collector:request.html.twig
return array (
);
