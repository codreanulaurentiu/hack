<?php

// WebProfilerBundle:Profiler:ajax_layout.html.twig
return array (
);
