<?php

// SwiftmailerBundle:Collector:swiftmailer.html.twig
return array (
);
